import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserRegistrationService } from '../user-registration.service';
@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.css']
})
export class UserRegistrationComponent {
  user = {
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    mobile: ''
  };

  constructor(private router: Router, private userRegistrationService: UserRegistrationService) {}

  onRegister() {
    if (this.user.password !== this.user.confirmPassword) {
      alert('Passwords do not match!');
      return;
    }

    this.userRegistrationService.registerUser(this.user).subscribe(
      response => {
        console.log('User registered:', response);
        this.router.navigate(['/user-login']);
      },
      error => {
        console.error('Registration error:', error);
      }
    );
  }
}