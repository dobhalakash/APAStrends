import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; // Import Router

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {
  captcha: string = '';
  captchaInput: string = '';
  captchaError: boolean = false;

  constructor(private router: Router) {} // Inject Router

  ngOnInit(): void {
    this.generateCaptcha();
  }

  generateCaptcha(): void {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
      captcha += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    this.captcha = captcha;
  }

  onSubmit(): void {
    if (this.captchaInput === this.captcha) {
      this.captchaError = false;
      alert('CAPTCHA is correct. Redirecting to the user dashboard.');
      this.router.navigate(['/user-dashboard']); // Redirect to the user dashboard or another route
    } else {
      this.captchaError = true;
      this.generateCaptcha();
      this.captchaInput = '';
    }
  }
}
