import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { AdminLoginComponent } from './admin-login/admin-login.component'; // Import AdminLoginComponent
import { ContactComponent } from './contact/contact.component'; // Correct import path
import { HomeComponent } from './home/home.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { LoginComponent } from './login/login.component';
import { NewReleaseComponent } from './new-release/new-release.component';
import { UserLoginComponent } from './user-login/user-login.component';

import { UserRegistrationComponent } from './user-registration/user-registration.component'; // Import UserRegistrationComponent

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contact', component: ContactComponent },
  { path: 'login', component: LoginComponent },
  { path: 'admin-login', component: AdminLoginComponent },
  { path: 'user-login', component: UserLoginComponent },
  { path: 'user-registration', component: UserRegistrationComponent },
  { path: 'new-release', component: NewReleaseComponent },
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'invoice', component: InvoiceComponent },

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
