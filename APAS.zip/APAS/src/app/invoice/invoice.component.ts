// src/app/invoice/invoice.component.ts
import { Component, OnInit } from '@angular/core';
import { InvoiceService } from '../invoice.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  invoiceData = {
    sellerName: '',
    address: '',
    phoneNo: '',
    email: '',
    gstin: '',
    state: '',
    billTo: '',
    shippingTo: '',
    invoiceNo: '',
    invoiceDate: '',
    billState: '',
    items: [
      { name: '', hsnSac: '', quantity: 0, unitPrice: 0, discount: 0, gst: 0, amount: 0 }
    ],
    subTotal: 0,
    discountTotal: 0,
    sgst: 0,
    cgst: 0,
    total: 0,
    received: 0,
    balance: 0,
    terms: ''
  };

  constructor(private invoiceService: InvoiceService) { }

  ngOnInit(): void { }

  saveInvoice(): void {
    this.invoiceService.saveInvoice(this.invoiceData).subscribe(
      response => {
        console.log('Invoice saved successfully!', response);
      },
      error => {
        console.error('Error saving invoice', error);
      }
    );
  }
}
