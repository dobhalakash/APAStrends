import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class InvoiceService {
  private apiUrl = '/api/invoices';

  constructor(private http: HttpClient) { }

  saveInvoice(invoiceData: any): Observable<any> {
    return this.http.post<any>(this.apiUrl, invoiceData);
  }
}