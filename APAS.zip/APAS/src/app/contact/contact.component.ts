import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  contact = {
    name: '',
    email: '',
    message: ''
  };

  captcha: string = '';
  captchaInput: string = '';
  captchaError: boolean = false;

  ngOnInit(): void {
    this.loadCaptcha();
  }

  loadCaptcha(): void {
    // Generate or fetch the captcha here
    this.captcha = '1234'; // Example static captcha
  }

  onSubmit(form: NgForm): void {
    if (this.captchaInput !== this.captcha) {
      this.captchaError = true;
      return;
    }
    this.captchaError = false;
    // Handle form submission
    console.log('Form Submitted', this.contact);
  }
}
